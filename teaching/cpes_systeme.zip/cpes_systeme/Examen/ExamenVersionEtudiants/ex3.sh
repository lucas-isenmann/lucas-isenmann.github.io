for i in $(seq #
do
    j=#
    echo $j #
done