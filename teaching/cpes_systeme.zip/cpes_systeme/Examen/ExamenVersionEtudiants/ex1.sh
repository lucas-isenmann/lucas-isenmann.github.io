read n
if (( $n % 2 == 0 ))
then
    #
else
    #
fi