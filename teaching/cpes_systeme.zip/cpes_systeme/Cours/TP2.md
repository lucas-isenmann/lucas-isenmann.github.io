
## Exercice 1

Avec nano créer un fichier poeme.txt qui contient un poème de 4 lignes (ou alors écrire n'importe quoi sur 4 lignes).

## Exercice 2

Créer un fichier "monfichier.txt" contenant "012".

En utilisant la commande 

    xxd -b monfichier.txt

en déduire le codage binaire des caractères 0, 1 et 2.
Calculer le codage décimale de ces caractères.


## Exercice 3

Le codage décimale de = est 61. Quel est son codage binaire ?
Le codage décimale de ~ est 126. Quel est son codage binaire ?


## Exercice 4

Récupérer la page html de www.wikipedia.fr à l'aide de la commande wget.

À l'aide de cat et grep, trouver dans quelle balise se situe le mot "Rechercher".

Faire de même avec www.google.com pour trouver où se situe "Google".

## Exercice 5

Dans le dossier 'ex5', lancer la commande suivante :

    bash script.sh

Et réaliser la consigne demandée.