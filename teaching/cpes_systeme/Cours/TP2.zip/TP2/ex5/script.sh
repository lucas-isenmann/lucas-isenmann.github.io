chmod -x indice1
chmod -r indice2
chmod -rx indice3
chmod -rwx indice4/salut.txt
echo "Trouver les 5 indices, à l'aide des commandes que vous avez apprises, qui vous serviront à trouver le mot code."