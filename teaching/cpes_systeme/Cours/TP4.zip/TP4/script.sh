
for i in {1..10}
do
   touch ex4/$i.txt
   if  ((1 + $RANDOM %2 == 1)); then
      chmod u+w ex4/$i.txt
   else
      chmod u-w ex4/$i.txt
   fi
   if  ((1 + $RANDOM %2 == 1)); then
      chmod u+x ex4/$i.txt
   else
      chmod u-x ex4/$i.txt
   fi
   if  ((1 + $RANDOM %2 == 1)); then
      chmod u+r ex4/$i.txt
   else
      chmod u-r ex4/$i.txt
   fi
   if  ((1 + $RANDOM %2 == 1)); then
      chmod o+w ex4/$i.txt
   else
      chmod o-w ex4/$i.txt
   fi
   if  ((1 + $RANDOM %2 == 1)); then
      chmod o+x ex4/$i.txt
   else
      chmod o-x ex4/$i.txt
   fi
   if  ((1 + $RANDOM %2 == 1)); then
      chmod o+r ex4/$i.txt
   else
      chmod o-r ex4/$i.txt
   fi
done



# EX5
n=20
for i in {1..10}
do
   touch ex5/$i.txt
done

chmod u-xrw ex8/comestible/legumes/.cachette/.cachette2/.indice.txt
chmod u-xrw ex8/comestible/legumes/.cachette/.cachette2
chmod u-xrw ex8/comestible/legumes/.cachette/

for i in {1..10}
do
   if  ((1 + $RANDOM % 2 == 1)); then
      j=$((1+($RANDOM%10)))
      echo $j
      rm ex5/$j.txt
      ln ex5/$i.txt ex5/$j.txt
   fi
done





