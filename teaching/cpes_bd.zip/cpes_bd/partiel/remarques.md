
Le bareme était sur 18 points, il faudrait rajouter une question.
Le sujet était légèrement court.
La modélisation portée sur une relation 0..1 0..1 qu'on avait pas vu.

Il faut enlever DerniereAP de la base cinema.odb

